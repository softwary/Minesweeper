package ait.hu.minesweeper.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import ait.hu.minesweeper.Model.MinesweeperModel;

import static ait.hu.minesweeper.Model.MinesweeperModel.*;


public class MinesweeperView extends View {
    private Paint paintBackground;
    private Paint paintLine;
    private Paint paintFont;
    private int BOARD_SIZE = MinesweeperModel.getInstance().BOARD_SIZE;

    public MinesweeperView(Context context,
                           @Nullable AttributeSet attrs) {
        super(context, attrs);

        paintBackground = new Paint();
        paintBackground.setColor(Color.GRAY);
        paintBackground.setStyle(Paint.Style.FILL);

        paintLine = new Paint();
        paintLine.setColor(Color.BLACK);
        paintLine.setStyle(Paint.Style.STROKE);
        paintLine.setStrokeWidth(5);
        double a = 21.13249;
        double b = 215.4701;
        double c = -0.2010105;
        double e = 2.71828182846;
        double fontsize = a + (b*(Math.pow(e,c*BOARD_SIZE)));
        paintFont = new Paint();
        paintFont.setColor(Color.RED);
        paintFont.setTextSize((float)fontsize);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawRect(0,
                0, getWidth(), getHeight(),
                paintBackground);

        drawGameArea(canvas);
        int x;
        int y;

        for (short i = 0; i < BOARD_SIZE; i++) {
            for (short j = 0; j < BOARD_SIZE; j++) {
                // not in flag mode && the game is activated
                //if (!getInstance().isFlagMode() && getInstance().isActivatedGame()) {

                    // wasClicked & is a Mine
                    if (getInstance().getFieldContent(i, j).wasClicked() &&
                            getInstance().getFieldContent(i, j).isMine() && !getInstance().getFieldContent(i,j).isFlagged() && !getInstance().isFlagMode()) {
                        drawMine(canvas, i, j);
                    }
                        else if(getInstance().getFieldContent(i, j).wasClicked() &&
                            getInstance().getFieldContent(i, j).isMine() && getInstance().getFieldContent(i,j).isFlagged()) {
                        drawFlag(canvas, i, j);
                    }

                        // wasClicked & is NOT a mine, draw INT
                    else if (getInstance().getFieldContent(i, j).wasClicked() &&
                            !getInstance().getFieldContent(i, j).isMine() && !getInstance().getFieldContent(i,j).isFlagged()) {
                        drawMinesAroundCount(canvas, i, j);
                    }
                    else if(getInstance().getFieldContent(i, j).wasClicked() &&
                            !getInstance().getFieldContent(i, j).isMine() && getInstance().getFieldContent(i,j).isFlagged()){
                        drawFlag(canvas, i, j);
                    }

                    if(getInstance().isFlagMode() && getInstance().getFieldContent(i,j).wasClicked() && getInstance().getFieldContent(i,j).isFlagged()){
                        x = ((getWidth() / BOARD_SIZE) / 2) + (i *(getWidth() / BOARD_SIZE));
                        y = ((getHeight() / BOARD_SIZE) / 2) + (j *(getHeight() / BOARD_SIZE));
                        canvas.drawText("", x, y, paintFont);


                    }


                    // In flag mode, doesn't matter if game is activated or not
                //} else if (getInstance().isFlagMode()) {

                    // if it is flagged
                  //  if (getInstance().getFieldContent(i, j).isFlagged()) {
                    //    drawFlag(canvas, i, j);
                   // }
               // }
            }
        }
    }

    private void drawMinesAroundCount(Canvas canvas, short i, short j) {
        int x = ((getWidth() / BOARD_SIZE) / 2) + (i *(getWidth() / BOARD_SIZE));
        int y = ((getHeight() / BOARD_SIZE) / 2) + (j *(getHeight() / BOARD_SIZE));
        String minesAround = Integer.toString(getInstance().getFieldContent(i, j).getMinesAround());
            canvas.drawText(minesAround, x, y, paintFont);
    }

    private void drawGameArea(Canvas canvas) {
        canvas.drawRect(0, 0, getWidth(), getHeight(), paintLine);

        for(int i = 1; i < BOARD_SIZE; i++){
            canvas.drawLine(0, i * getHeight() / BOARD_SIZE, getWidth(), i * getHeight() / BOARD_SIZE, paintLine);

            canvas.drawLine(i * getWidth() / BOARD_SIZE, 0, i * getWidth() / BOARD_SIZE, getHeight(), paintLine);
        }




    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // make things get revealed on touch is all this one does.
        // if not clicked yet, set to clicked
        // if it is a mine, deactivate game and reveal all fields
        if (event.getAction() == MotionEvent.ACTION_DOWN) {

            int tX = ((int) event.getX() / (getWidth() / BOARD_SIZE));
            int tY = ((int) event.getY() / (getHeight() / BOARD_SIZE));

            //String tXtY = "TOUCH~~~Value OF tX";
            //Log.i(tXtY, tX + ", tY:" + tY);


            if (getInstance().isActivatedGame()) {
                // if NOT flag mode
                if (!getInstance().isFlagMode()) {

                    // if it was NOT clicked yet:
                    if (!getInstance().getFieldContent((short) tX, (short) tY).wasClicked()) {

                        // if it IS a mine:
                        if (getInstance().getFieldContent((short) tX, (short) tY).isMine()) {

                            // set it as clicked (thereby causing it to be drawn by other methods)
                            getInstance().getFieldContent((short) tX, (short) tY).setWasClicked(true);
                            getInstance().setGameOver();
                            proclaimGameOver();

                            // if it is NOT a mine
                        } else if (!getInstance().getFieldContent((short) tX, (short) tY).isMine()) {

                            getInstance().getFieldContent((short) tX, (short) tY).setWasClicked(true);
                        }
                    } else if (getInstance().getFieldContent((short) tX, (short) tY).wasClicked()) {
                        if(getInstance().hasWon() && getInstance().isActivatedGame()) {
                            proclaimWinner();
                            getInstance().setActivatedGame(false);
                        }
                        invalidate();
                    }

                    // if flag mode
                } else if (getInstance().isFlagMode() && getInstance().isActivatedGame()) {

                    // if not flagged already
                    if (!getInstance().getFieldContent((short) tX, (short) tY).wasClicked()) {
                        // set as clicked & flagged
                        getInstance().getFieldContent((short) tX, (short) tY).setWasClicked(true);
                        getInstance().getFieldContent((short) tX, (short) tY).setFlagged(true);
                        //String yesFlagMode = "~~~~setFlagged(true)";
                        //Log.i(yesFlagMode, "tX: " + tX + ", tY:" + tY);
                    } else if(getInstance().getFieldContent((short) tX, (short) tY).wasClicked() && getInstance().getFieldContent((short)tX,(short)tY).isFlagged()){
                        getInstance().getFieldContent((short) tX, (short) tY).setWasClicked(false);
                        getInstance().getFieldContent((short) tX, (short) tY).setFlagged(false);
                    }
                }
                if(getInstance().hasWon()) {
                    proclaimWinner();
                    getInstance().setActivatedGame(false);
                }
                invalidate();
            }
        }
        return true;
    }

    private void drawMine(Canvas canvas, short i, short j) {
        int x = ((getWidth() / BOARD_SIZE) / 2) + (i *(getWidth() / BOARD_SIZE));
        int y = ((getHeight() / BOARD_SIZE) / 2) + (j *(getHeight() / BOARD_SIZE));

            //String mineAtZeroZero = "~~~~DrawMine1 (0,0)";
            //Log.i(mineAtZeroZero, "The mine is at i,j (" + i + ", " + j + "). The x, y is (" +
                  //  x +", " + y+ ")");

            /* FOR SOME REASON, WHEN THE MINE IS AT 0,0, THE X,Y = (-84, -84))
            WHY THOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
            */
            canvas.drawText("💣", x, y, paintFont);


    }

    private void drawFlag(Canvas canvas, short i, short j) {
        int x = ((getWidth() / BOARD_SIZE) / 2) + (i *(getWidth() / BOARD_SIZE));
        int y = ((getHeight() / BOARD_SIZE) / 2) + (j *(getHeight() / BOARD_SIZE));
            canvas.drawText("🚩", x, y, paintFont);
    }

    private void proclaimGameOver() {
        String over = "Game over. Press reset game to play again!";
        Toast.makeText(getContext(), over, Toast.LENGTH_LONG).show();
    }

    private void proclaimWinner() {
        String over = "CONGRATULATIONS!!! YOU WIN!!!! Press reset game to play again!";
        Toast.makeText(getContext(), over, Toast.LENGTH_LONG).show();
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = MeasureSpec.getSize(widthMeasureSpec);
        int h = MeasureSpec.getSize(heightMeasureSpec);
        int d = w == 0 ? h : h == 0 ? w : w < h ? w : h;
        setMeasuredDimension(d, d);
    }

    public void resetGame() {
        getInstance().setupFullBoard();
        invalidate();
    }
}